<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;

class ProductoController extends Controller
{
    public function index()
    {
        return Producto::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'codpro' => 'required',
            'nomprd' => 'required',
            // Agrega aquí otras validaciones según sea necesario
        ]);

        $producto = new Producto;
        $producto->codpro = $request->codpro;
        $producto->nomprd = $request->nomprd;
        // Asigna otros campos según sea necesario
        $producto->save();

        return $producto;
    }

    public function show(Producto $producto)
    {
        return $producto;
    }

    public function update(Request $request, Producto $producto)
    {
        // Agrega el código para actualizar el producto según sea necesario
    }

    public function destroy(Producto $producto)
    {
        // Agrega el código para eliminar el producto según sea necesario
    }
}
