<?php

namespace App\Http\Controllers;

use App\Models\Cartegoria;
use Illuminate\Http\Request;

class CartegoriaController extends Controller
{
    
    public function index()
    {
        return Cartegoria::all();
    }

   
    public function store(Request $request)
    {
        $request->validate([
            'idcate' => 'required',
            'nocate' => 'required'
        ]);
    
        $cartegoria = new Cartegoria;
        $cartegoria->idcate = $request->idcate;
        $cartegoria->nocate = $request->nocate;
        $cartegoria->save();
    
        return $cartegoria;
    }
    

    
    public function show(Cartegoria $cartegoria)
    {
        return $cartegoria;
    }

    
    public function update(Request $request, Cartegoria $cartegoria)
    {
        //
    }

    
    public function destroy(Cartegoria $cartegoria)
    {
        //
    }
}
