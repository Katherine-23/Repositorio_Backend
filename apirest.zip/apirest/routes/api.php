<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\CartegoriaController;
use App\Http\Controllers\ProductoController;

Route::apiResource('clientes',ClienteController::class);
Route::apiResource('productos', ProductoController::class);
Route::apiResource('cartegorias', CartegoriaController::class);

